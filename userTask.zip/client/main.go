package main

import (
	"context"
	"fmt"
	"log"
	pb "userTask/user"

	"google.golang.org/grpc"
)

const (
	address = "localhost:50051"
)

// func CreateUserProfile(client pb.NewUserProfilesClient, user *pb.CreateUserProfileRequest) {

// }

func main() {
	//Set up a connection to the gRPC server.
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()

	client := pb.NewUserProfilesClient(conn)

	user := &pb.CreateUserProfileRequest{
		UserProfile: &pb.UserProfile{
			Email:     "email",
			FirstName: "abkjas",
			LastName:  "bcbc",
			//BirthDate: "jkasx",
			Telephones: []string{
				"asmlckma",
				"lkanclkas",
			},
		},
	}

	resp, err := client.CreateUserProfile(context.Background(), user)

	if err != nil {
		log.Printf("Error %v", err)
	} else {
		log.Println(resp)
	}

	getReq := &pb.GetUserProfileRequest{
		Id: resp.Id,
	}

	r, err := client.GetUserProfile(context.Background(), getReq)

	if err != nil {
		log.Printf("Error %v", err)
	} else {
		fmt.Println(r)
	}

}
